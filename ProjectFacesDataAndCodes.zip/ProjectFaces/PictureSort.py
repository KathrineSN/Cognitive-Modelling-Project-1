from os import walk
import numpy as np
import shutil
import random
random.seed(7)

filenames = next(walk("UTKFace"), (None, None, []))[2]

files = [file.split("_") for file in filenames]

women = []
men = []
for i in files:
    if i[1] == "0":
        men.append(i)
    else:
        women.append(i)
        

menMiddleAged = []
womenMiddleAged = []

for i in men:
    if int(i[0]) >= 20 and int(i[0]) <= 60:
        menMiddleAged.append(i)
        
for i in women:
    if int(i[0]) >= 20 and int(i[0]) <= 60:
        womenMiddleAged.append(i)
        

a = random.sample(menMiddleAged, 200)
b = random.sample(womenMiddleAged, 200)

combinedPictures = a+b

for i in combinedPictures:
    
    filename = '_'.join(i)
    shutil.move("UTKFace/" + filename, "SampledPhotos/")
    
    
import glob
import cv2

images = [cv2.imread(file) for file in glob.glob("SampledPhotos/*.jpg")]
